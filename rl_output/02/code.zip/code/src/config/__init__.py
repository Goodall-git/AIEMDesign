
import re
import sys
import pathlib
from dataclasses import dataclass, field
from typing import List, Optional

from pyhocon import ConfigFactory, ConfigTree

from src.torchutils.common import get_free_port, apply_modifications
from src.torchutils.typed_args import TypedArgs, add_argument


def is_valid_domain(value):
    pattern = re.compile(
        r'^(([a-zA-Z]{1})|([a-zA-Z]{1}[a-zA-Z]{1})|'
        r'([a-zA-Z]{1}[0-9]{1})|([0-9]{1}[a-zA-Z]{1})|'
        r'([a-zA-Z0-9][-_.a-zA-Z0-9]{0,61}[a-zA-Z0-9]))\.'
        r'([a-zA-Z]{2,13}|[a-zA-Z0-9-]{2,30}.[a-zA-Z]{2,3})$'
    )
    return True if pattern.match(value) else False


def is_valid_ip(str):
    p = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
    return True if p.match(str) else False



@dataclass
class Args(TypedArgs):
    output_dir: str = field(default_factory=lambda: add_argument("-o", "--output-dir", default=""))
    conf: str = field(default_factory=lambda: add_argument("--conf", default=""))
    modifications: List[str] = field(default_factory=lambda: add_argument("-M", nargs='+', help="list"))

    world_size: int = field(default_factory=lambda: add_argument("--world-size", default=1))
    dist_backend: str = field(default_factory=lambda: add_argument("--dist-backend", default="nccl"))
    dist_url: Optional[str] = field(default_factory=lambda: add_argument("--dist-url", default=None))
    node_rank: int = field(default_factory=lambda: add_argument("--node-rank", default=0))


def get_args(argv=sys.argv):
    args, _ = Args.from_known_args(argv)
    args.output_dir = pathlib.Path(args.output_dir)

    if args.dist_url is None:
        args.dist_url = f"tcp://127.0.0.1:{get_free_port()}"
    elif is_valid_domain(args.dist_url) or is_valid_ip(args.dist_url):
        args.dist_url = f"tcp://{args.dist_url}:{get_free_port()}"

    args.conf: ConfigTree = ConfigFactory.parse_file(args.conf)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    apply_modifications(modifications=args.modifications, conf=args.conf)

    return args
