import torch
import torch.nn as nn

from src.registry import LOSS
import src.loss  # noqa: F401  触发注册


N_FREQ = 101
I0, I1 = 75, 99     # 7.5 ~ 9.9 GHz


def _curve_with_dip(channel: int, depth_db: float) -> torch.Tensor:
    """构造一条在带内某点出现指定深度凹陷、其余频点为 -10 dB 的曲线。"""
    y = torch.full((3 * N_FREQ,), -10.0)
    y[I0:I1 + 1] = -10.0
    y[I0 + 12] = -10.0 - depth_db
    return y


def _loss(**kwargs):
    return LOSS.build_from({
        "type_": "ResonanceWeightedLoss",
        "n_freq": N_FREQ,
        "band": [7.5, 9.9],
        "depth_threshold_db": 3.0,
        "edge_margin_points": 1,
        "weight": 12.0,
        "criterion": {"type_": "L1Loss"},
        **kwargs,
    })


def test_resonance_mask_uses_band_edges_not_max():
    """从带边单调下降的曲线不应被判为带内凹陷。"""
    loss = _loss()
    y = torch.full((1, 3 * N_FREQ), -10.0)
    y[0, I0:I1 + 1] = torch.linspace(-10.0, -40.0, I1 - I0 + 1)
    assert loss._resonance_mask(y).item() is False


def test_resonance_mask_detects_true_dip():
    loss = _loss()
    y = torch.stack([_curve_with_dip(0, 8.0)])
    assert loss._resonance_mask(y).item() is True


def test_depth_loss_penalizes_shallow_prediction():
    """真值有深凹陷时，预测太平的曲线应当比预测正确的曲线损失更大。"""
    loss = _loss(depth_weight=2.0, position_weight=0.0)
    target = torch.stack([_curve_with_dip(0, 8.0)])
    flat = torch.full_like(target, -10.0)
    good = target.clone()

    assert loss(flat, target).item() > loss(good, target).item()


def test_depth_loss_suppresses_false_dip_on_flat_target():
    """真值平坦时，预测出深凹陷要额外受罚（防止虚假谐振）。"""
    loss = _loss(depth_weight=2.0, position_weight=0.0,
                 depth_negative_weight=1.0, depth_negative_margin_db=0.5)
    target = torch.full((1, 3 * N_FREQ), -10.0)
    flat = target.clone()
    false_dip = torch.stack([_curve_with_dip(0, 8.0)])

    assert loss(false_dip, target).item() > loss(flat, target).item()


def test_depth_weight_zero_matches_weighted_l1():
    """depth_weight=0 时退化为纯加权 L1，便于与旧实验对照。"""
    loss = _loss(weight=1.0, depth_weight=0.0, position_weight=0.0)
    target = torch.stack([_curve_with_dip(0, 8.0)])
    outputs = target + 1.0
    assert torch.allclose(loss(outputs, target), nn.L1Loss()(outputs, target))


def test_position_loss_reduces_with_correct_position():
    loss = _loss(depth_weight=0.0, position_weight=1.0, position_temperature=0.5)
    target = torch.stack([_curve_with_dip(0, 8.0)])
    wrong = target.clone()
    wrong[0, I0:I1 + 1] = -10.0
    wrong[0, I0 + 4] = -18.0

    assert loss(target, target).item() < loss(wrong, target).item()
