#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
本脚本的功能
============
将两个 CSV 文件合并为一个 Parquet 数据集，用于智能电磁设计 / 机器学习任务。

输入：
1. 拓扑 CSV：
   - 第一行：表头
   - 每一行：16 个 0/1 数字
   - 可视为一个 4x4 的电磁拓扑矩阵
   - 可选：第 1 列为样本 id

2. S 参数 CSV：
   - 第一行：表头
   - 每一行：1000 个浮点数
   - 表示 2GHz ~ 20GHz 的 S 参数幅度（线性幅度，范围 0~1）
   - 可选：第 1 列为样本 id

输出：
- 一个 Parquet 文件（启用压缩）
- 每一行表示一个样本：
    {
      id (可选),
      topology : 4x4 的矩阵（嵌套 list）
      s_curve  : 长度 1000 的 S 参数曲线
    }

设计目标：
- 结构清晰，方便深度学习 / 强化学习直接读取
- 存储紧凑，适合大规模数据集
- 教学友好，逻辑清楚
"""

import argparse
import sys
from typing import Optional, Tuple

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq


def _infer_id_and_payload(
    df: pd.DataFrame,
    payload_len: int
) -> Tuple[Optional[pd.Series], pd.DataFrame]:
    """
    解析 CSV 的列结构，判断是否存在样本 id 列。

    支持两种常见数据格式（教学中非常重要）：
    ------------------------------------------------
    情况 1：
        [x1, x2, ..., xN]
        → 没有显式 id，按“行顺序”一一对应

    情况 2：
        [id, x1, x2, ..., xN]
        → 第一列是样本编号，用于显式对齐

    参数：
    - df          : 读取后的 DataFrame
    - payload_len : 有效数据的列数（拓扑=16，S参数=1000）

    返回：
    - id 列（如果不存在则返回 None）
    - payload 数据（去掉 id 后的 DataFrame）
    """
    ncols = df.shape[1]

    # 情况 1：只有 payload
    if ncols == payload_len:
        return None, df

    # 情况 2：id + payload
    if ncols == payload_len + 1:
        return df.iloc[:, 0], df.iloc[:, 1:]

    # 其他情况：直接报错，防止“悄悄读错数据”
    raise ValueError(
        f"列数不符合预期：期望 {payload_len} 或 {payload_len + 1} 列，"
        f"但实际为 {ncols} 列"
    )


def _validate_binary_matrix(mat: np.ndarray) -> None:
    """
    校验拓扑矩阵是否合法（必须全是 0 或 1）

    这一步在科研中非常关键：
    - 防止误把连续参数当成拓扑
    - 防止 CSV 中混入 NaN / 其他非法值
    """
    if not np.isin(mat, [0, 1]).all():
        bad = mat[~np.isin(mat, [0, 1])]
        raise ValueError(
            f"拓扑矩阵中发现非 0/1 的非法值，例如：{bad[:10]}"
        )


def build_parquet(
    topo_csv: str,
    s_csv: str,
    out_parquet: str,
    compression: str = "zstd",
) -> None:
    """
    主处理函数：读取 → 校验 → 结构化 → 写 Parquet

    参数：
    - topo_csv    : 拓扑 CSV 文件路径
    - s_csv       : S 参数 CSV 文件路径
    - out_parquet : 输出 Parquet 路径
    - compression : Parquet 压缩算法（推荐 zstd）
    """

    # =========================
    # 1. 读取 CSV 文件
    # =========================
    topo_df = pd.read_csv(topo_csv)
    s_df = pd.read_csv(s_csv)

    # =========================
    # 2. 解析是否存在 id 列
    # =========================
    topo_id, topo_payload = _infer_id_and_payload(topo_df, payload_len=16)
    s_id, s_payload = _infer_id_and_payload(s_df, payload_len=1000)

    # =========================
    # 3. 样本数量一致性检查
    # =========================
    if len(topo_payload) != len(s_payload):
        raise ValueError(
            f"样本数量不一致：拓扑={len(topo_payload)}，"
            f"S 参数={len(s_payload)}"
        )

    # =========================
    # 4. id 对齐逻辑
    # =========================
    # 教学重点：
    # - 如果两边都有 id → 强制检查一致
    # - 如果只有一边有 id → 保留，但无法验证
    use_id = None

    if topo_id is not None and s_id is not None:
        if not topo_id.reset_index(drop=True).equals(
            s_id.reset_index(drop=True)
        ):
            raise ValueError(
                "检测到两个 CSV 的 id 列不一致，"
                "请先对齐或改用按 id join 的方式"
            )
        use_id = topo_id.reset_index(drop=True)

    elif topo_id is not None:
        use_id = topo_id.reset_index(drop=True)

    elif s_id is not None:
        use_id = s_id.reset_index(drop=True)

    # =========================
    # 5. 拓扑数据处理
    # =========================
    # 转为 int8：节省存储空间
    topo_arr = topo_payload.to_numpy(dtype=np.int8, copy=True)

    if topo_arr.shape[1] != 16:
        raise ValueError("拓扑数据列数必须为 16")

    _validate_binary_matrix(topo_arr)

    # =========================
    # 6. S 参数数据处理
    # =========================
    # 使用 float32：对 S 参数精度完全足够
    s_arr = s_payload.to_numpy(dtype=np.float32, copy=True)

    if s_arr.shape[1] != 1000:
        raise ValueError("S 参数数据列数必须为 1000")

    # 范围检查（不强制报错，给教学提示）
    if np.nanmin(s_arr) < 0.0 or np.nanmax(s_arr) > 1.0:
        print(
            f"[WARN] S 参数超出 [0,1]，"
            f"min={np.nanmin(s_arr):.4f}, "
            f"max={np.nanmax(s_arr):.4f}",
            file=sys.stderr,
        )

    # =========================
    # 7. 构建“模型友好”的数据结构
    # =========================
    # 每一行：
    #   topology : 4x4 的二维结构
    #   s_curve  : 1000 点一维曲线
    topology_col = [
        topo_arr[i].reshape(4, 4).tolist()
        for i in range(topo_arr.shape[0])
    ]

    s_curve_col = [
        s_arr[i].tolist()
        for i in range(s_arr.shape[0])
    ]

    out_df = pd.DataFrame(
        {
            "topology": topology_col,
            "s_curve": s_curve_col,
        }
    )

    if use_id is not None:
        out_df.insert(0, "id", use_id)

    # =========================
    # 8. 写入 Parquet 文件
    # =========================
    # Parquet 特点：
    # - 列式存储
    # - 支持嵌套结构
    # - 对机器学习数据集非常友好
    table = pa.Table.from_pandas(
        out_df,
        preserve_index=False
    )

    pq.write_table(
        table,
        out_parquet,
        compression=compression,
        use_dictionary=True,
    )


def main():
    """
    命令行入口函数
    """
    parser = argparse.ArgumentParser(
        description="将电磁拓扑 + S 参数 CSV 合并为压缩 Parquet 数据集"
    )
    parser.add_argument("--topo_csv", required=True, help="拓扑 CSV 文件路径")
    parser.add_argument("--s_csv", required=True, help="S 参数 CSV 文件路径")
    parser.add_argument("--out", required=True, help="输出 Parquet 路径")
    parser.add_argument(
        "--compression",
        default="zstd",
        help="Parquet 压缩方式（zstd / snappy / gzip）"
    )

    args = parser.parse_args()

    build_parquet(
        topo_csv=args.topo_csv,
        s_csv=args.s_csv,
        out_parquet=args.out,
        compression=args.compression,
    )

    print(f"处理完成，已生成：{args.out}")


if __name__ == "__main__":
    main()
