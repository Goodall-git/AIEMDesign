import pandas as pd

df = pd.read_parquet("data/dataset.parquet")

topology = df.loc[0, "topology"]  # 4×4 拓扑矩阵
s_curve  = df.loc[0, "s_curve"]   # 1000 点 S11 曲线

print(topology, s_curve)