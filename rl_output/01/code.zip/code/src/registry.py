from src.torchutils.registry import Registry

LOSS = Registry("loss")
DATA = Registry("data")
MODEL = Registry("model")
OPTIMIZER = Registry("optimizer")
SCHEDULER = Registry("scheduler")
REWARD = Registry("reward")

