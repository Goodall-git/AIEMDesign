# dataset_em_parquet.py
# -*- coding: utf-8 -*-

import os
import numpy as np
import pandas as pd
import logging
import torch
from torch.utils.data import Dataset
from torch.utils import data
import torchvision.transforms as T
from torchvision.transforms import Lambda
from typing import Tuple, Union, Optional, Tuple, Callable

from dataclasses import dataclass

from src.registry import DATA

_logger = logging.getLogger(__name__)


def scale_to_minus1_1(x):
    return x * 2.0 - 1.0

def get_train_transforms():
    return T.Compose([T.Lambda(scale_to_minus1_1)])

def get_val_transforms():
    return T.Compose([T.Lambda(scale_to_minus1_1)])
    
@dataclass
class EMParquetConfig:
    topology_shape: str = "1x4x4"          # "4x4" 或 "1x4x4"
    topology_dtype: torch.dtype = torch.float32
    s_dtype: torch.dtype = torch.float32
    topology_data_raw_shape: Tuple[int, int] = (4, 4)
    s_curve_data_raw_shape: Tuple[int] = (1000,)


import numpy as np

def _to_2d_float_array(x, shape=(4, 4), name="topology"):
    """
    将 parquet 读出来的嵌套结构 x 可靠地转换成指定 shape 的 float32 ndarray。
    兼容：list-of-list、object array、list of arrays、pyarrow list 等。
    """
    arr = np.asarray(x)

    # 情况 A：已经是 (4,4) 之类二维
    if arr.ndim == 2:
        out = arr.astype(np.float32, copy=False)

    # 情况 B：变成了 (4,) 的 object 数组，每个元素是长度 4 的序列
    elif arr.ndim == 1 and arr.shape[0] == shape[0]:
        try:
            out = np.stack([np.asarray(row, dtype=np.float32) for row in arr], axis=0)
        except Exception as e:
            raise ValueError(f"{name} 无法从 object array stack 成二维数组：ndim={arr.ndim}, shape={arr.shape}") from e

    else:
        raise ValueError(f"{name} 维度异常：ndim={arr.ndim}, shape={arr.shape}")

    if out.shape != shape:
        raise ValueError(f"{name} 形状错误：{out.shape}，期望 {shape}")

    return out

def _to_1d_float_array(x, shape=(1000,), name="s_curve"):
    arr = np.asarray(x, dtype=np.float32)
    if arr.shape != shape:
        raise ValueError(f"{name} 形状错误：{arr.shape}，期望 {shape}")
    return arr


class EMTopologyS11ParquetDataset(Dataset):
    """
    PyTorch 风格的数据集类，用于读取电磁拓扑 + S11 幅度曲线的 Parquet 数据集。

    Parquet 文件中每一行包含：
    - topology : 4x4 的二值矩阵（嵌套 list）
    - s_curve  : 长度为 1000 的 S11 幅度曲线

    __getitem__ 返回：
    - topology_tensor : (4,4) 或 (1,4,4)
    - s_curve_tensor  : (1000,)
    """

    def __init__(
        self,
        parquet_path: str,
        config: Optional[EMParquetConfig] = None,
        topology_transform: Optional[Callable[[torch.Tensor], torch.Tensor]] = None,
        s_transform: Optional[Callable[[torch.Tensor], torch.Tensor]] = None,
    ):
        super().__init__()

        self.parquet_path = parquet_path
        self.cfg = config or EMParquetConfig()
        self.topology_transform = topology_transform
        self.s_transform = s_transform

        # 读取 Parquet 文件
        self.df = pd.read_parquet(self.parquet_path)

        # 必要列检查
        required_cols = {"topology", "s_curve"}
        missing = required_cols - set(self.df.columns)
        if missing:
            raise ValueError(
                f"Parquet 文件缺少必要列 {missing}，实际列为 {list(self.df.columns)}"
            )


    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        row = self.df.iloc[idx]

        # =====================
        # 1. 读取拓扑矩阵
        # =====================
        topo = _to_2d_float_array(
            row["topology"],
            shape=self.cfg.topology_data_raw_shape,
            name="topology",
        )

        if topo.shape != self.cfg.topology_data_raw_shape:
            raise ValueError(
                f"第 {idx} 个样本的 topology 形状为 {topo.shape}，期望 {self.cfg.topology_data_raw_shape}"
            )

        topo_t = torch.from_numpy(topo).to(self.cfg.topology_dtype)

        # 是否增加 channel 维度
        if self.cfg.topology_shape == "1x4x4":
            topo_t = topo_t.unsqueeze(0)  # (1,4,4)
        elif self.cfg.topology_shape == "4x4":
            pass
        else:
            raise ValueError(
                f"未知 topology_shape={self.cfg.topology_shape}，"
                "可选 '4x4' 或 '1x4x4'"
            )

        # =====================
        # 2. 读取 S11 曲线
        # =====================
        s = _to_1d_float_array(
            row["s_curve"],
            shape=self.cfg.s_curve_data_raw_shape,
            name="s_curve",
        )  

        if s.shape != self.cfg.s_curve_data_raw_shape:
            raise ValueError(
                f"第 {idx} 个样本的 s_curve 形状为 {s.shape}，期望 {self.cfg.s_curve_data_raw_shape}"
            )

        s_t = torch.from_numpy(s).to(self.cfg.s_dtype)
        
        # =====================
        # 3. 应用自定义 transform（可选）
        # =====================
        # 单独 transform
        if self.topology_transform is not None:
            topo_t = self.topology_transform(topo_t)

        if self.s_transform is not None:
            s_t = self.s_transform(s_t)

        return topo_t, s_t

def _em_parquet_dataloader_impl(
    root: str,
    batch_size: int,
    num_workers: int,
    config: Optional[EMParquetConfig] = None,
    train_filename: str = "train.parquet",
    val_filename: str = "val.parquet",
    pin_memory: bool = True,
    persistent_workers: Optional[bool] = None,
    drop_last: bool = True,
    # 可选：与你现有训练框架对齐（如果你后续接 DDP sampler）
    train_sampler=None,
    val_sampler=None,
) -> Tuple[data.DataLoader, data.DataLoader]:
    """
    基于 EMTopologyS11ParquetDataset 构建 train/val 的 DataLoader。

    期望目录结构：
      root/
        train.parquet
        val.parquet

    返回：
      train_loader, val_loader
    """
    cfg = config or EMParquetConfig()

    if persistent_workers is None:
        # num_workers>0 才能启用 persistent_workers
        persistent_workers = num_workers > 0

    train_path = os.path.join(root, train_filename)
    val_path = os.path.join(root, val_filename)

    if not os.path.exists(train_path):
        raise FileNotFoundError(f"未找到训练集文件：{train_path}")
    if not os.path.exists(val_path):
        raise FileNotFoundError(f"未找到验证集文件：{val_path}")

    trainset = EMTopologyS11ParquetDataset(train_path, config=cfg, 
                                           topology_transform=get_train_transforms())
    valset = EMTopologyS11ParquetDataset(val_path, config=cfg,
                                         topology_transform=get_val_transforms())

    _logger.info(
        f"[EM] Loading Parquet datasets: "
        f"train(len={len(trainset)}) val(len={len(valset)})"
    )

    train_loader = data.DataLoader(
        trainset,
        batch_size=batch_size,
        shuffle=(train_sampler is None),
        sampler=train_sampler,
        num_workers=num_workers,
        pin_memory=pin_memory,
        persistent_workers=persistent_workers,
        drop_last=drop_last,
    )

    val_loader = data.DataLoader(
        valset,
        batch_size=batch_size,
        shuffle=False,              # 验证集通常不 shuffle
        sampler=val_sampler,
        num_workers=num_workers,
        pin_memory=pin_memory,
        persistent_workers=persistent_workers,
        drop_last=False,
    )

    return train_loader, val_loader

@DATA.register
def EMParquetDataloader(
    root: str,
    batch_size: int,
    num_workers: int,
    config: Optional[EMParquetConfig] = None,
    train_filename: str = "train.parquet",
    val_filename: str = "val.parquet",
    pin_memory: bool = True,
    persistent_workers: Optional[bool] = None,
    drop_last: bool = True,
    **kwargs):
    return _em_parquet_dataloader_impl(
        root, batch_size, num_workers, config, 
        train_filename, val_filename, pin_memory, 
        persistent_workers, drop_last, **kwargs
    )
