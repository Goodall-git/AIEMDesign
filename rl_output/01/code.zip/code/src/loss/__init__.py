import torch.nn as nn
from src.registry import LOSS

LOSS.register(nn.MSELoss)
LOSS.register(nn.CrossEntropyLoss)